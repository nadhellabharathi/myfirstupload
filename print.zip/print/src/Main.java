public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        int sum=0;
        for(int i=0;i<10;i++){
            System.out.println("Hai");
            System.out.println(sum+i);
        }
    }
}